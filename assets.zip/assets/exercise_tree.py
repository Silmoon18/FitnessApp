from exercises import exercises
import pydot
import os
class Node:
    def __init__(self, name):
        self.name = name
        self.children = {}

    def add_child(self, name, child):
        self.children[name] = child

    def get_child(self, name):
        return self.children.get(name)
    
def build_workout_plan_tree():
    # Create root of the tree
    root = Node('workout plan')

    # Level 1 nodes
    calisthenics = Node('calisthenics')
    powerlifting = Node('powerlifting')
    hypertrophy = Node('hypertrophy')

    # Adding level 1 nodes to root
    root.add_child('calisthenics', calisthenics)
    root.add_child('powerlifting', powerlifting)
    root.add_child('hypertrophy', hypertrophy)

    # Calisthenics level 2 nodes
    experience_levels = ['novice', 'beginner', 'intermediate', 'advanced', 'elite']
    for level in experience_levels:
        calisthenics.add_child(level, Node(level))

    # Powerlifting level 2 nodes
    powerlifting_exercises = ['bench press', 'deadlift', 'squats']
    for exercise in powerlifting_exercises:
        powerlifting.add_child(exercise, Node(exercise))

    # Hypertrophy level 2 node
    muscle_groups = Node('muscle groups')
    hypertrophy.add_child('muscle groups', muscle_groups)

    # Calisthenics level 3 nodes for novice, beginner, intermediate
    for level in experience_levels[:3]:
        calisthenics.children[level].add_child('progression program', Node('progression program'))

    # Advanced and elite levels point to muscle groups
    for level in experience_levels[3:]:
        calisthenics.children[level].children = muscle_groups.children

    # Muscle groups level 4 nodes
    muscles = ['chest', 'upper back', 'lats', 'shoulders', 'quads', 
               'hamstrings', 'glutes', 'calves', 'abs', 'triceps', 
               'biceps', 'forearms', 'adductors']
    for muscle in muscles:
        muscle_groups.add_child(muscle, Node(muscle))

    # Progression program level 4 nodes
    progression_exercises = ['Pushups', 'Pull ups', 'Squats', 'Leg Raises', 
                             'Bridges', 'Skills']
    for exercise in progression_exercises:
        calisthenics.children['novice'].children['progression program'].add_child(exercise, Node(exercise))
        calisthenics.children['beginner'].children['progression program'].add_child(exercise, Node(exercise))
        calisthenics.children['intermediate'].children['progression program'].add_child(exercise, Node(exercise))
    
    # Define muscle group divisions, for level 5 nodes
    muscle_group_divisions = {
        'chest': ['upper chest', 'middle chest', 'lower chest'],
        'shoulders': ['front delts', 'side delts', 'rear delts'],
        'quads': ['vastus medialis and lateralis', 'rectus femoris'],
        'lats': ['upper lats', 'lumbar lats', 'lower lats'],
        'glutes': ['gluteus medius', 'gluteus maximus'],
        'hamstrings': ['bicep femoris'],
        'calves': ['soleus', 'gastroc'],
        'upper back': ['upper traps','mid traps', 'rhomboids'],
        'triceps': ['long head', 'side and medial head'],
        'biceps': ['bicep brachii', 'brachialis'],
        'abs': ['upper abs', 'lower abs'],
        'forearms': ['brachioradialis', 'wrist extensor', 'wrist flexors'],
        'adductors': ['adductor magnus']
    }

    # Add muscle group divisions to the muscle_groups node
    for muscle, divisions in muscle_group_divisions.items():
        muscle_node = muscle_groups.get_child(muscle) if muscle_groups.get_child(muscle) else Node(muscle)
        muscle_groups.add_child(muscle, muscle_node)
        for division in divisions:
            division_node = Node(division)
            muscle_node.add_child(division, division_node)

    return root

def add_exercises_to_tree(node, exercises):
    for exercise in exercises:
        biases = exercise['bias'].split(', ')
        for bias in biases:
            # Navigate through the tree to find the correct muscle group and bias
            for muscle_group_node in node.get_child('hypertrophy').get_child('muscle groups').children.values():
                division_node = muscle_group_node.get_child(bias)
                if division_node:
                    # Add the exercise to the division node as a new node
                    exercise_node = Node(exercise['name'])
                    division_node.add_child(exercise['name'], exercise_node)
                    # Now add the hypertrophy scale as a child of this exercise node
                    rating_node = Node(f"{exercise['hypertrophy_scale']}")
                    exercise_node.add_child(f"{exercise['hypertrophy_scale']}", rating_node)
                 

workout_plan_root = build_workout_plan_tree()

# Add exercises to the tree
add_exercises_to_tree(workout_plan_root, exercises)

def print_tree(node, level=0):
    print('|-------->' * level + node.name)
    for child in node.children.values():
        print_tree(child, level + 1)
print_tree(workout_plan_root)


def flatten_tree(node, parent_name=None, level=0, flat_list=[]):
    node_info = {
        'name': node.name,
        'parent': parent_name,
        'level': level,
        'children': [child.name for child in node.children.values()]
    }
    
    # Include the hypertrophy_scale if it exists on the node
    if hasattr(node, 'hypertrophy_scale'):
        node_info['hypertrophy_scale'] = node.hypertrophy_scale
    
    flat_list.append(node_info)
    
    for child in node.children.values():
        flatten_tree(child, node.name, level + 1, flat_list)
    
    return flat_list


#Print the flattened list.
print(flatten_tree)