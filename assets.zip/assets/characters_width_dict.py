character_widths= {'a': 2.8, 'b': 2.8, 'c': 2.6, 'd': 2.8, 'e': 2.6, 'f': 1.6, 'g': 2.8, 'h': 2.6, 'i': 1.0, 'j': 1.2, 'k': 2.4, 'l': 1.2, 'm': 4.2, 'n': 2.6, 'o': 2.8, 'p': 2.8, 'q': 2.8, 'r': 1.6, 's': 2.4, 't': 1.8, 'u': 2.8, 'v': 2.6, 'w': 3.6, 'x': 2.4, 'y': 2.6, 'z': 2.2, 'A': 3.0, 'B': 2.6, 'C': 3.4, 'D': 3.0, 'E': 2.2, 'F': 2.2, 'G': 3.4, 'H': 3.0, 'I': 1.2, 'J': 2.4, 'K': 2.8, 'L': 2.0, 'M': 3.8, 'N': 3.0, 'O': 3.4, 'P': 2.6, 'Q': 3.4, 'R': 2.6, 'S': 2.6, 'T': 2.6, 'U': 2.8, 'V': 3.0, 'W': 4.4, 'X': 3.0, 'Y': 2.6, 'Z': 2.4, ' ': 1.0, '-': 2.6}

def get_text_width(text):
    return sum(character_widths.get(c, 0.5) for c in text)


# import freetype

# FONT_POINTS = 16
# DISPLAY_DPI = 96
# face = freetype.Face("Poppins-SemiBold.ttf")

# face.set_char_size(FONT_POINTS << 6, FONT_POINTS << 6, DISPLAY_DPI, DISPLAY_DPI)

# character_widths = {}
# for char in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ -":
#     pen_x = 0
#     previous_glyph = 0
#     glyph_index = face.get_char_index(char)
#     if face.has_kerning and previous_glyph and glyph_index:
#         delta = face.get_kerning(previous_glyph, glyph_index)
#         pen_x += delta.x >> 6
#     face.load_glyph(glyph_index, freetype.FT_LOAD_FLAGS['FT_LOAD_RENDER'])
#     pen_x += face.glyph.advance.x >> 6
#     character_widths[char] = pen_x

# # Normalize the widths so they're relative to the width of a space
# space_width = character_widths[' ']
# character_widths = {char: width / space_width for char, width in character_widths.items()}
# print(character_widths)